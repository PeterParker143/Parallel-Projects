import { Component, OnInit } from '@angular/core';
import { CustomerServiceService } from '../customer-service.service';
import { ShowBalanceComponent } from '../show-balance/show-balance.component';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  amount: number;
  constructor(private customerService:CustomerServiceService,private show: ShowBalanceComponent) { }
  ngOnInit() {
  }
  withdrawAmount(accnum,amount){
  this.customerService.withdrawAmount(accnum,amount).subscribe(data => {
    if(data===1)
{
  window.alert('Withdraw Successful');
  this.amount=this.show.showBalance(accnum);
}
else{
  window.alert('Try Again');
}
  });
 }
}
