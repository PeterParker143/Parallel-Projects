package com.bank.service;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.bank.bean.Banking;
import com.bank.bean.Transactions;
import com.bank.dao.BankDao;
import com.bank.dao.BankDaoImpl;
import com.bank.exception.BankException;

public class BankServiceImpl implements BankService{

	BankDao bankDao=new BankDaoImpl();
	
	@Override
	public void addAccount(Banking bank,Transactions tran) {
		bankDao.addUserAccount(bank,tran);
		
	}

	@Override
	public String checkBalance(int accountNo) {
		return  bankDao.getBalance(accountNo);
	}

	@Override
	public String depositMoney(int accountNumber, long amount, Transactions tran) {
		return  bankDao.depositMoney(accountNumber, amount, tran);
	}

	@Override
	public String withdrawMoney(int accountNumber, long amount, Transactions tran) {
		return  bankDao.withdrawMoney(accountNumber, amount, tran);
	}


	@Override
	public String transferMoney(int accountNumber01, long amount01, int accountNumber02,Transactions tran1,Transactions tran2) {
		return bankDao.transferMoney(accountNumber01,amount01,accountNumber02,tran1,tran2);
	}

	@Override
	public String getTransactionDetails(int accountNumber) {

		HashMap<Integer,Transactions> hm=bankDao.printTransactions(accountNumber);
		
		Set set=hm.entrySet();
		Iterator iterator=set.iterator();
		String trans = "" ;
		while(iterator.hasNext())
		{
			Map.Entry pair = (Map.Entry)iterator.next();
			int tid=(int) pair.getKey();
			Transactions transaction=(Transactions) pair.getValue();
			trans=trans+"\n"+"Transaction ID :"+tid+"|| Account number :"+transaction.getAcno()+"|| Transaction Type :"+transaction.getOpertaion();
		}
		return trans;
	}
}
