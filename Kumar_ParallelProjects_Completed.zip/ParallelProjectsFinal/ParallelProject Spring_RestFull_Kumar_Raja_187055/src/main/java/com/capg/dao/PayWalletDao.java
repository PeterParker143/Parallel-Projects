package com.capg.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capg.entities.PayWalletBean;


@Repository
public interface PayWalletDao extends JpaRepository<PayWalletBean, Long> {

	@Query("select accNo,pwd,name,address from PayWalletBean where accNo =?1")
	Optional<PayWalletBean> accountsDetails(@Param("c") Long accNo);

	@Query("select be.bal from PayWalletBean be where be.accNo =?1")
	Optional<Double> showBalance(@Param("c") Long accNo);
}
