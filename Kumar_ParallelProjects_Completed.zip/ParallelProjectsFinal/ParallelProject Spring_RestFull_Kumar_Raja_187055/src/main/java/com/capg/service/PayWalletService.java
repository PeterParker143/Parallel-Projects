package com.capg.service;

import java.util.List;

import com.capg.entities.PayWalletBean;
import com.capg.entities.TransactionBean;
import com.capg.exception.PayWalletException;


public interface PayWalletService {

	public PayWalletBean createAccount(PayWalletBean bank) throws PayWalletException;
	public PayWalletBean accountsDetails(Long accNo) throws PayWalletException;
	public Double showBalance(Long accNo) throws PayWalletException;
	public Double deposit(Long accNo, Double amt) throws PayWalletException;
	public Double withdraw(Long accNo, Double amt) throws PayWalletException;
	public Double fundTransfer(Long accNo1, Double amt, Long accNo2) throws PayWalletException;
	public List<TransactionBean> printTransaction(Long accNo);

}
