import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerServiceService } from '../customer-service.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
  user: Customer;
constructor(private customerService:CustomerServiceService) 
{  this.user =new Customer();}
   
  ngOnInit() {
  }

  createBankAccount(username,phoneNumber,psw,balance):void {
    this.user.username=username;
    this.user.phoneNumber=phoneNumber;
    this.user.password=psw;
    this.user.balance=balance;

    this.customerService.createBankAccount(this.user).subscribe(data => {
    alert("Account created successfully.");
    });
}
}

