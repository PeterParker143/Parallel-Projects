package com.cg.bank.exception;

public class BankException extends Exception{
	public BankException()
	{
		
	}
	public BankException(String msg)
	{
		super(msg);
	}

}
